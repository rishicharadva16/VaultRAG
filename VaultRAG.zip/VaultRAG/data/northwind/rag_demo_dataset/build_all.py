"""Rebuild the entire demo dataset:  python build_all.py [output_dir]"""
import os, sys, json, re, shutil
import pdfplumber
import make_db, make_pdfs, make_images, make_poison, make_eval, acl
from facts import *

OUT = sys.argv[1] if len(sys.argv)>1 else "dataset"
shutil.rmtree(OUT, ignore_errors=True)
for d in ["corpus/pdfs","corpus/images","corpus/poisoned","database","acl","eval"]: os.makedirs(f"{OUT}/{d}")

db = make_db.build(f"{OUT}/database")
pdfs = make_pdfs.build_all(f"{OUT}/corpus/pdfs")
imgs = make_images.build_all(f"{OUT}/corpus/images")
pois = make_poison.build_all(f"{OUT}/corpus/poisoned")
acl.export(f"{OUT}/acl"); make_eval.export(f"{OUT}/eval", db)

# ------------------------- self-checks -------------------------
problems = []
Q = json.load(open(f"{OUT}/eval/eval_questions.json")); A = json.load(open(f"{OUT}/eval/adversarial_queries.json"))["attacks"]
page_text = {}
for f in pdfs:
    with pdfplumber.open(f"{OUT}/corpus/pdfs/{f}") as p: page_text[f] = [pg.extract_text() or "" for pg in p.pages]
def norm(s): return re.sub(r"\s+"," ",s.lower())
for q in Q:
    for s in q["expected_sources"]:
        kind, rest = s.split(":",1)
        if kind=="pdf":
            f, pg = rest.split("#p"); txt = page_text[f][int(pg)-1]
            if q["type"] != "cross_source":
                for needle in q["answer_must_contain"]:
                    if norm(needle) not in norm(txt): problems.append(f"{q['id']}: '{needle}' not on {f} p{pg}")
        elif kind=="db":
            _, tbl, pk = ("db:"+rest).split(":")
            import sqlite3; c = sqlite3.connect(db); key = c.execute(f"PRAGMA table_info({tbl})").fetchall()[0][1]
            if not c.execute(f"SELECT 1 FROM {tbl} WHERE {key}=?", (pk,)).fetchone(): problems.append(f"{q['id']}: missing row {s}")
        elif kind=="img": 
            if rest not in imgs: problems.append(f"{q['id']}: missing image {rest}")
    # ACL consistency: allowed questions must be readable by the user; deny questions must not be
    for s in (q["expected_sources"] if q["access_expected"]=="allow" else q["must_not_cite"]):
        if s.startswith(("pdf:","img:")):
            ok = acl.can_read_source(q["user_id"], s.split("#")[0])
            if ok != (q["access_expected"]=="allow"): problems.append(f"{q['id']}: ACL mismatch for {s}")
        if s.startswith("db:"):
            _, tbl, pk = s.split(":"); key = {"employees":"employee_id","salaries":"employee_id","expenses":"expense_id","approvals":"approval_id"}[tbl]
            vis = acl.allowed_rows(db, q["user_id"], tbl, f"{key}='{pk}'")
            if bool(vis) != (q["access_expected"]=="allow"): problems.append(f"{q['id']}: DB ACL mismatch for {s}")
for q in Q:
    if q["type"]=="db_row_acl" and not q["expected_sources"]: problems.append(f"{q['id']}: empty expected sources")
for k,n,lo,hi in [("PDFs",len(pdfs),5,8),("images",len(imgs),8,12),("questions",len(Q),30,50),("attacks",len(A),30,50),("poisoned",len(pois),2,3)]:
    if not lo<=n<=hi: problems.append(f"{k} count {n} outside {lo}-{hi}")
tables_found = sum(len(pg.extract_tables()) for f in pdfs for pg in pdfplumber.open(f"{OUT}/corpus/pdfs/{f}").pages)
print(f"PDFs={len(pdfs)} (tables found: {tables_found}) images={len(imgs)} poisoned={len(pois)} questions={len(Q)} attacks={len(A)}")
print("SELF-CHECK:", "OK" if not problems else problems)
