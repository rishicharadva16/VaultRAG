import os, json, math, random
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageEnhance
import numpy as np
from facts import *

FD = "/usr/share/fonts/truetype/dejavu/"
def F(size, bold=False): return ImageFont.truetype(FD+("DejaVuSans-Bold.ttf" if bold else "DejaVuSans.ttf"), size)

class Canvas:
    """Draws text and records ground-truth boxes (x0,y0,x1,y1) for OCR/bbox evaluation."""
    def __init__(self, w, h, bg=(255,255,255)):
        self.img = Image.new("RGB",(w,h),bg); self.d = ImageDraw.Draw(self.img); self.items = []
    def text(self, xy, s, size=22, bold=False, fill=(20,20,20), field=None, anchor="la"):
        f = F(size,bold); self.d.text(xy, s, font=f, fill=fill, anchor=anchor)
        bb = self.d.textbbox(xy, s, font=f, anchor=anchor)
        self.items.append(dict(text=s, field=field, bbox=[int(v) for v in bb]))
    def rect(self, box, outline=(60,60,60), width=2, fill=None): self.d.rectangle(box, outline=outline, width=width, fill=fill)
    def line(self, p, q, fill=(60,60,60), width=2): self.d.line([p,q], fill=fill, width=width)

def rotate_items(items, angle, size_before, size_after):
    """Transform bboxes the same way PIL rotates the image (counter-clockwise, expand=True)."""
    th = math.radians(angle); c, s = math.cos(th), math.sin(th)
    cx0, cy0 = size_before[0]/2, size_before[1]/2; cx1, cy1 = size_after[0]/2, size_after[1]/2
    out = []
    for it in items:
        x0,y0,x1,y1 = it["bbox"]; pts=[]
        for (x,y) in [(x0,y0),(x1,y0),(x1,y1),(x0,y1)]:
            dx,dy = x-cx0, y-cy0
            pts.append((dx*c + dy*s + cx1, -dx*s + dy*c + cy1))
        xs=[p[0] for p in pts]; ys=[p[1] for p in pts]
        out.append(dict(it, bbox=[int(min(xs)),int(min(ys)),int(max(xs)),int(max(ys))],
                        polygon=[[round(a,1),round(b,1)] for a,b in pts]))
    return out

def invoice(vendor, addr, gstin, inv_no, date, lines, subtotal_rows, total, bill_to=COMPANY, ref=None):
    cv = Canvas(900, 1200)
    cv.text((50,40), vendor, 34, True, (20,50,100), "vendor")
    cv.text((50,90), addr, 18); cv.text((50,118), f"GSTIN: {gstin}", 18, field="vendor_gstin")
    cv.text((650,45), "TAX INVOICE", 26, True, field="title")
    cv.text((560,110), f"Invoice No: {inv_no}", 20, True, field="invoice_no")
    cv.text((560,142), f"Date: {date}", 20, field="date")
    cv.line((50,180),(850,180))
    cv.text((50,200), "Bill To:", 18, True); cv.text((50,228), bill_to, 20, field="bill_to")
    cv.text((50,256), "Rajkot, Gujarat 360001", 18)
    if ref: cv.text((560,228), ref, 18, field="reference")
    y = 330
    cv.rect((50,y,850,y+40), fill=(225,232,242)); cv.text((60,y+8),"Description",18,True); cv.text((560,y+8),"Qty",18,True); cv.text((650,y+8),"Amount (Rs)",18,True)
    y += 40
    for desc, qty, amt in lines:
        cv.rect((50,y,850,y+44)); cv.text((60,y+10),desc,18,field="line_item"); cv.text((570,y+10),str(qty),18)
        cv.text((840,y+10), inr(amt), 18, anchor="ra", field="line_amount"); y += 44
    y += 20
    for label, amt in subtotal_rows:
        cv.text((560,y), label, 19); cv.text((840,y), inr(amt), 19, anchor="ra", field=label.lower().split()[0]); y += 36
    cv.line((540,y+4),(850,y+4)); y += 14
    cv.text((560,y),"TOTAL (Rs)",22,True); cv.text((840,y),inr(total),22,True,anchor="ra",field="total")
    cv.text((50,1090),"Payment terms: as per agreement. Subject to Rajkot jurisdiction.",16,fill=(90,90,90))
    cv.text((50,1120),"This is a computer generated invoice (synthetic test data).",16,fill=(90,90,90))
    return cv

def add_noise(img, sigma=10, seed=1):
    a = np.asarray(img).astype(np.int16); rng = np.random.default_rng(seed)
    a = a + rng.normal(0, sigma, a.shape); return Image.fromarray(np.clip(a,0,255).astype(np.uint8))

def handwriting(cv, xy, s, size, fill, jitter, rnd):
    """Fake marker handwriting: per-character offset/size jitter, bbox recorded per line."""
    x, y = xy; x0 = x
    for ch in s:
        f = F(size + rnd.randint(-2,3), True); dy = rnd.randint(-jitter, jitter)
        cv.d.text((x, y+dy), ch, font=f, fill=fill); x += cv.d.textlength(ch, font=f) + rnd.randint(0,2)
    cv.items.append(dict(text=s, field="whiteboard_line", bbox=[int(x0),int(y-6),int(x),int(y+size+10)]))

def build_all(out):
    os.makedirs(out, exist_ok=True); gt = {}; rnd = random.Random(SEED+7)
    def save(name, img, items, kind, note, fmt="PNG", **kw):
        img.save(os.path.join(out,name), **({"quality":kw.get("quality",92)} if fmt=="JPEG" else {}))
        gt[name] = dict(kind=kind, size=list(img.size), note=note, text_regions=items)

    # 1 clean Apex April invoice
    i = INV_APR
    cv = invoice(APEX["name"],"Plot 14, GIDC Aji, Rajkot","24AAECA1234F1Z5",i["no"],i["date"],
        [("Logistics service fee - April 2026",1,i["fee"])],[("GST @ 18%",i["gst"])],i["total"], ref="Contract: VC-2026-014")
    save("invoice_01_apex_apr.png", cv.img, cv.items, "invoice", "Clean digital invoice.")
    # 2 BrightByte
    cv = invoice("BrightByte Software LLP","3rd Floor, Baner Road, Pune","27AAFFB5678K1Z2","INV-BB-2291","10 Jul 2026",
        [("DevTools Suite annual licence",40,100000)],[("GST @ 18%",18000)],118000, ref="PO: PO-2026-077")
    save("invoice_02_brightbyte.png", cv.img, cv.items, "invoice", "Clean digital invoice; matches PO-2026-077 and EXP-1003.")
    # 3 QuickPrint
    cv = invoice("QuickPrint Services","12 Kalawad Road, Rajkot","24AABPQ9012L1Z8","INV-QP-0388","27 Jul 2026",
        [("Printing - delivery challans",5000,7000)],[("GST @ 18%",1260)],8260)
    save("invoice_03_quickprint.png", cv.img, cv.items, "invoice", "Clean digital invoice; matches EXP-1007.")
    # 4 blurry Apex May invoice (low quality)
    m = INV_MAY
    cv = invoice(APEX["name"],"Plot 14, GIDC Aji, Rajkot","24AAECA1234F1Z5",m["no"],m["date"],
        [("Logistics service fee - May 2026",1,m["fee"]),("Fuel surcharge - May 2026",1,m["fuel"])],[("GST @ 18%",m["gst"])],m["total"], ref="Contract: VC-2026-014")
    img = cv.img.filter(ImageFilter.GaussianBlur(2.3)).resize((600,800)).resize((900,1200))
    img = add_noise(ImageEnhance.Contrast(img).enhance(0.8), 9, 4)
    save("invoice_04_apex_may_blurry.jpg", img, cv.items, "invoice", "LOW QUALITY: blurred, down-sampled and noisy. Includes the 5% fuel surcharge that breaches the 3% contract cap.", "JPEG", quality=55)
    # 5 rotated scan of Shree Ganesh invoice
    cv = invoice("Shree Ganesh Stationers","Shop 7, Dhebar Road, Rajkot","24AAHFS3456M1Z1","INV-SGS-5517","02 Aug 2026",
        [("A4 paper reams",20,2000),("Files and folders",1,1000)],[("GST @ 18%",540)],3540)
    ang = 7.0; big = cv.img.rotate(ang, expand=True, fillcolor=(205,205,205), resample=Image.BICUBIC)
    items = rotate_items(cv.items, ang, cv.img.size, big.size)
    img = add_noise(big.convert("L").convert("RGB"), 14, 5)
    save("invoice_05_rotated_scan.jpg", img, items, "invoice", "ROTATED 7 degrees counter-clockwise, greyscale scan with noise. bbox are axis-aligned boxes of rotated text; 'polygon' gives exact corners.", "JPEG", quality=80)
    # 6 hotel receipt
    h = HOTEL; cv = Canvas(700, 900, (252,250,242))
    cv.text((350,40), h["name"].split(",")[0].upper(), 30, True, field="vendor", anchor="ma"); cv.text((350,82),"Pune, Maharashtra",18,anchor="ma")
    cv.text((350,115),"GUEST FOLIO / TAX INVOICE",20,True,anchor="ma"); cv.line((40,155),(660,155))
    for k,(a,b,fld) in enumerate([("Folio No:","LGH-PN-20931","folio_no"),("Guest:",h["guest"],"guest"),("Check-in:","20 Aug 2026","check_in"),("Check-out:",h["date"],"check_out"),("Nights:",str(h["nights"]),"nights")]):
        cv.text((50,180+k*36),a,19,True); cv.text((220,180+k*36),b,19,field=fld)
    cv.line((40,380),(660,380))
    cv.text((50,400),"Room charges (2 x Rs 5,500)",19); cv.text((650,400),inr(h["nights"]*h["rate"]),19,anchor="ra",field="room_charges")
    cv.text((50,440),"GST @ 12%",19); cv.text((650,440),inr(h["gst"]),19,anchor="ra",field="gst")
    cv.line((40,490),(660,490)); cv.text((50,510),"TOTAL (Rs)",24,True); cv.text((650,510),inr(h["total"]),24,True,anchor="ra",field="total")
    cv.text((350,820),"Thank you for staying with us (synthetic test data)",15,anchor="ma",fill=(110,110,110))
    save("receipt_hotel_lotus.png", cv.img, cv.items, "receipt", "Hotel receipt: Rs 5,500/night exceeds the Rs 4,500 L1-L3 Tier-1 cap.")
    # 7-8 ID cards (clearly synthetic / specimen)
    for emp in ["E1004","E1010"]:
        e = next(x for x in EMPLOYEES if x[0]==emp); cv = Canvas(860,540,(245,248,252))
        cv.rect((10,10,850,530),(31,58,95),4); cv.d.rectangle((10,10,850,90),fill=(31,58,95))
        cv.text((30,28),COMPANY.upper(),28,True,(255,255,255)); cv.text((690,58),"SPECIMEN",18,True,(255,200,0))
        cv.rect((40,130,240,380),(120,120,120),2,(210,215,225)); cv.text((140,255),"PHOTO",24,fill=(120,120,120),anchor="mm")
        rows = [("Name",e[1],"name"),("Employee ID",e[0],"employee_id"),("Department",e[2],"department"),("Designation",e[3],"designation"),
                ("Blood group",rnd.choice(["O+","A+","B+","AB+"]),"blood_group"),("Emergency",f"+91 90{rnd.randint(10000000,99999999)}","emergency_contact")]
        for k,(a,b,fld) in enumerate(rows):
            cv.text((280,130+k*44),a+":",19,True); cv.text((460,130+k*44),b,19,field=fld)
        cv.text((40,440),f"Valid till: 31 Mar 2028   Location: {e[7]}",18,field="valid_till")
        cv.text((40,480),"If found return to HR, Rajkot. Synthetic test data.",15,fill=(100,100,100))
        save(f"id_card_{emp}.png", cv.img, cv.items, "id_proof", f"Synthetic employee ID card for {emp}. Contains PII-like fields.")
    # 9 whiteboard photo (handwriting, uneven lighting, slight rotation)
    cv = Canvas(1200, 800, (238,240,236)); cv.rect((30,30,1170,770),(150,150,150),10)
    lines = [("SPRINT 14 PLAN",(80,70),44,(20,40,160)),("Launch: 15 Nov",(80,160),40,(190,30,30)),
             ("Asha - API v2 + auth",(80,250),34,(20,40,160)),("Ravi - vendor review",(80,330),34,(20,40,160)),
             ("Apex SLA review - 20 Oct",(80,410),34,(20,120,60)),("Hire 12 eng (Board OK 14 Aug)",(80,490),34,(20,120,60)),
             ("Demo to client: Fri 24 Oct",(80,570),34,(190,30,30)),("TODO: ask IT re: MFA rollout",(80,650),30,(60,60,60))]
    for s,xy,sz,col in lines: handwriting(cv, xy, s, sz, col, 4, rnd)
    base = cv.img; w,h = base.size
    grad = Image.fromarray((np.tile(np.linspace(0.78,1.0,w),(h,1))[...,None]*np.asarray(base)).astype(np.uint8))
    ang = -3.0; big = grad.rotate(ang, expand=True, fillcolor=(90,80,70), resample=Image.BICUBIC)
    items = rotate_items(cv.items, ang, (w,h), big.size)
    save("whiteboard_sprint.jpg", add_noise(big.filter(ImageFilter.GaussianBlur(0.8)),6,9), items, "whiteboard", "Photo-style whiteboard with jittered handwriting, gradient lighting and 3 degree tilt.", "JPEG", quality=85)
    # 10 purchase order
    cv = Canvas(900, 1000)
    cv.text((50,40),COMPANY,30,True,(20,50,100)); cv.text((620,45),"PURCHASE ORDER",26,True,field="title")
    cv.text((560,100),"PO No: PO-2026-077",20,True,field="po_no"); cv.text((560,132),"Date: 02 Jul 2026",20,field="date")
    cv.text((50,110),"Vendor:",18,True); cv.text((50,140),"BrightByte Software LLP",20,field="vendor"); cv.text((50,170),"Pune, Maharashtra",18)
    cv.rect((50,260,850,300),fill=(225,232,242)); cv.text((60,268),"Item",18,True); cv.text((520,268),"Qty",18,True); cv.text((650,268),"Amount (Rs)",18,True)
    cv.rect((50,300,850,346)); cv.text((60,312),"DevTools Suite annual licence",18,field="line_item"); cv.text((530,312),"40",18); cv.text((840,312),inr(100000),18,anchor="ra")
    cv.text((560,380),"GST @ 18%",19); cv.text((840,380),inr(18000),19,anchor="ra"); cv.text((560,430),"TOTAL (Rs)",22,True); cv.text((840,430),inr(118000),22,True,anchor="ra",field="total")
    cv.text((50,520),"Approved by: Ravi Menon, Engineering Manager",18,field="approved_by"); cv.text((50,900),"Synthetic test data.",15,fill=(110,110,110))
    save("purchase_order_PO-2026-077.png", cv.img, cv.items, "purchase_order", "Clean purchase order.")
    json.dump(gt, open(os.path.join(out,"image_ground_truth.json"),"w"), indent=1)
    return list(gt)

if __name__ == "__main__":
    print(build_all("out_test/images"))
