import sqlite3, random, csv, os
from facts import *

def build(out_dir):
    rnd = random.Random(SEED+1)
    emps, sal = build_people()
    emp_by = {e["employee_id"]: e for e in emps}

    # ---- planted expenses: facts also appear in PDFs / images ----
    exp = [
     ("EXP-1001","E1024","Vendor Invoice",INV_MAY["total"],"2026-06-06","Apex Logistics May service + fuel surcharge",APEX["name"],INV_MAY["no"],"on_hold"),
     ("EXP-1002","E1010","Travel",HOTEL["total"],"2026-08-24","Pune hotel, 2 nights, client workshop",HOTEL["name"],"LGH-PN-20931","pending"),
     ("EXP-1003","E1003","Software",118000,"2026-07-12","DevTools Suite annual licences (40 seats)","BrightByte Software LLP","INV-BB-2291","approved"),
     ("EXP-1004","E1024","Vendor Invoice",INV_APR["total"],"2026-05-07","Apex Logistics April service fee",APEX["name"],INV_APR["no"],"approved"),
     ("EXP-1005","E1004","Training",75000,"2026-07-20","Cloud certification bootcamp","CloudSkills Academy","CSA-7781","approved"),
     ("EXP-1006","E1019","Office Supplies",3540,"2026-08-02","Stationery for warehouse office","Shree Ganesh Stationers","INV-SGS-5517","approved"),
     ("EXP-1007","E1019","Office Supplies",8260,"2026-07-29","Printing of delivery challans","QuickPrint Services","INV-QP-0388","approved"),
    ]
    cats = {"Travel":(1800,28000),"Meals":(300,3500),"Software":(2000,60000),"Training":(5000,45000),
            "Office Supplies":(400,9000),"Client Entertainment":(1500,18000)}
    vendors = {"Travel":["IndiGo","Rajdhani Cabs","Hotel Sayaji"],"Meals":["Cafe Rio","Spice Tree"],
        "Software":["CloudNimbus","BrightByte Software LLP"],"Training":["CloudSkills Academy","LearnWorks"],
        "Office Supplies":["QuickPrint Services","Shree Ganesh Stationers"],"Client Entertainment":["Spice Tree","The Grand Thakar"]}
    n = 1008
    while len(exp) < 40:
        c = rnd.choice(list(cats)); e = rnd.choice(emps)
        amt = rnd.randint(*cats[c]); amt = round(amt/10)*10
        d = f"2026-{rnd.randint(6,9):02d}-{rnd.randint(1,28):02d}"
        st = rnd.choice(["approved"]*5+["pending","pending","rejected"])
        exp.append((f"EXP-{n}",e["employee_id"],c,amt,d,f"{c} expense",rnd.choice(vendors[c]),f"REF-{rnd.randint(10000,99999)}",st)); n+=1

    # ---- approvals ----
    comments = {"EXP-1001":("E1002","on_hold","Fuel surcharge Rs 20,000 is 5% of monthly fee; contract cap is 3%. Clarify with vendor."),
                "EXP-1002":("E1003","pending",""),
                "EXP-1005":("E1003","approved","Approved by line manager."),
                "EXP-1003":("E1002","approved","Within controller limit."),
                "EXP-1004":("E1002","approved","As per contract VC-2026-014."),
                "EXP-1006":("E1018","approved",""),"EXP-1007":("E1018","approved","")}
    appr = []
    for i,(eid,emp,cat,amt,d,desc,ven,ref,st) in enumerate(exp, start=1):
        if eid in comments:
            ap,dec,cm = comments[eid]
        else:
            mgr = emp_by[emp]["manager_id"]
            ap = "E1002" if (amt>50000 or not mgr) else mgr
            if ap == emp: ap = "E1001" if emp=="E1002" else "E1002"
            dec = {"approved":"approved","rejected":"rejected","pending":"pending"}[st]
            cm = {"rejected":"Receipt missing.","approved":"","pending":""}[st]
        dd = None if dec=="pending" else d.replace(d[-2:], f"{min(28,int(d[-2:])+2):02d}")
        appr.append((f"APR-{1000+i}",eid,ap,1,dec,dd,cm))

    os.makedirs(out_dir, exist_ok=True)
    path = os.path.join(out_dir,"northwind.db")
    if os.path.exists(path): os.remove(path)
    con = sqlite3.connect(path); cur = con.cursor()
    cur.executescript("""
    CREATE TABLE employees(employee_id TEXT PRIMARY KEY,name TEXT,email TEXT,department TEXT,designation TEXT,
        grade TEXT,manager_id TEXT,join_date TEXT,location TEXT,status TEXT,date_of_birth TEXT,personal_phone TEXT);
    CREATE TABLE salaries(employee_id TEXT PRIMARY KEY,annual_ctc INTEGER,revision_pct INTEGER,revised_ctc INTEGER,
        effective_date TEXT,bank_account_last4 TEXT);
    CREATE TABLE expenses(expense_id TEXT PRIMARY KEY,employee_id TEXT,category TEXT,amount INTEGER,expense_date TEXT,
        description TEXT,vendor TEXT,invoice_ref TEXT,status TEXT);
    CREATE TABLE approvals(approval_id TEXT PRIMARY KEY,expense_id TEXT,approver_id TEXT,level INTEGER,decision TEXT,
        decided_on TEXT,comments TEXT);
    CREATE TABLE users(user_id TEXT PRIMARY KEY,employee_id TEXT,role TEXT);
    """)
    cols = list(emps[0]); cur.executemany(f"INSERT INTO employees VALUES({','.join('?'*len(cols))})",[tuple(e[c] for c in cols) for e in emps])
    cols = list(sal[0]); cur.executemany(f"INSERT INTO salaries VALUES({','.join('?'*len(cols))})",[tuple(s[c] for c in cols) for s in sal])
    cur.executemany("INSERT INTO expenses VALUES(?,?,?,?,?,?,?,?,?)",exp)
    cur.executemany("INSERT INTO approvals VALUES(?,?,?,?,?,?,?)",appr)
    cur.executemany("INSERT INTO users VALUES(?,?,?)",USERS)
    con.commit()
    # CSV + SQL dump alongside the .db
    for t in ["employees","salaries","expenses","approvals","users"]:
        rows = cur.execute(f"SELECT * FROM {t}").fetchall(); hdr=[c[0] for c in cur.description]
        with open(os.path.join(out_dir,f"{t}.csv"),"w",newline="") as f:
            w=csv.writer(f); w.writerow(hdr); w.writerows(rows)
    with open(os.path.join(out_dir,"northwind_dump.sql"),"w") as f:
        for line in con.iterdump(): f.write(line+"\n")
    con.close()
    return path

if __name__ == "__main__":
    p = build("out_test"); print(p)
