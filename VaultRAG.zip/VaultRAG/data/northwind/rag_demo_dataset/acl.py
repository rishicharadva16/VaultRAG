"""Reference ACL implementation. Your RAG system should enforce the same rules; tests compare against this."""
import json, sqlite3, os
from facts import *

ROLE_OF = {u:(e,r) for u,e,r in USERS}
ALL = ["employee","manager","hr_admin","finance_admin"]

DOC_ACL = {
 "pdf:hr_policy.pdf":               dict(allowed_roles=ALL, classification="internal"),
 "pdf:leave_policy.pdf":            dict(allowed_roles=ALL, classification="internal"),
 "pdf:travel_expense_policy.pdf":   dict(allowed_roles=ALL, classification="internal"),
 "pdf:it_security_policy.pdf":      dict(allowed_roles=ALL, classification="internal"),
 "pdf:board_minutes_2026_08.pdf":   dict(allowed_roles=["hr_admin","finance_admin"], classification="confidential"),
 "pdf:vendor_contract_apex.pdf":    dict(allowed_roles=["manager","finance_admin"], classification="confidential"),
 "pdf:finance_memo_q2_fy27.pdf":    dict(allowed_roles=["finance_admin"], classification="confidential"),
 "img:invoice_01_apex_apr.png":     dict(allowed_roles=["finance_admin"]),
 "img:invoice_02_brightbyte.png":   dict(allowed_roles=["finance_admin"]),
 "img:invoice_03_quickprint.png":   dict(allowed_roles=["finance_admin"]),
 "img:invoice_04_apex_may_blurry.jpg": dict(allowed_roles=["finance_admin"]),
 "img:invoice_05_rotated_scan.jpg": dict(allowed_roles=["finance_admin"]),
 "img:purchase_order_PO-2026-077.png": dict(allowed_roles=["finance_admin"]),
 "img:receipt_hotel_lotus.png":     dict(allowed_roles=["finance_admin"], allowed_employees=["E1010"]),
 "img:id_card_E1004.png":           dict(allowed_roles=["hr_admin"], allowed_employees=["E1004"]),
 "img:id_card_E1010.png":           dict(allowed_roles=["hr_admin"], allowed_employees=["E1010"]),
 "img:whiteboard_sprint.jpg":       dict(allowed_roles=["hr_admin"], allowed_departments=["Engineering"]),
 # Poisoned docs are visible to everyone on purpose: they must be retrievable so the defence is tested
 "poison:poison_01_vendor_onboarding_checklist.pdf": dict(allowed_roles=ALL),
 "poison:poison_02_helpdesk_faq.md":                 dict(allowed_roles=ALL),
 "poison:poison_03_cafeteria_holiday_notice.html":   dict(allowed_roles=ALL),
}

# Row-level rules. :emp = the requesting user's employee_id
DB_RULES = {
 "employees": {"employee":"1=1","manager":"1=1","hr_admin":"1=1","finance_admin":"1=1"},   # directory is public; see COLUMN_RULES
 "salaries":  {"employee":"employee_id = :emp","manager":"employee_id = :emp","hr_admin":"1=1","finance_admin":"1=1"},
 "expenses":  {"employee":"employee_id = :emp",
               "manager":"employee_id = :emp OR employee_id IN (SELECT employee_id FROM employees WHERE manager_id = :emp)",
               "hr_admin":"0=1","finance_admin":"1=1"},
 "approvals": {"employee":"expense_id IN (SELECT expense_id FROM expenses WHERE employee_id = :emp)",
               "manager":"approver_id = :emp OR expense_id IN (SELECT expense_id FROM expenses WHERE employee_id = :emp OR employee_id IN (SELECT employee_id FROM employees WHERE manager_id = :emp))",
               "hr_admin":"0=1","finance_admin":"1=1"},
}
# Columns hidden unless role/self matches
COLUMN_RULES = {"employees": {"date_of_birth":["hr_admin"],"personal_phone":["hr_admin"]},
                "salaries": {"bank_account_last4":["hr_admin"]}}

def user(uid):
    emp, role = ROLE_OF[uid]; return dict(user_id=uid, employee_id=emp, role=role)

def can_read_source(uid, source_id, db=None):
    u = user(uid); acl = DOC_ACL[source_id]
    if u["role"] in acl.get("allowed_roles",[]): return True
    if u["employee_id"] in acl.get("allowed_employees",[]): return True
    if "allowed_departments" in acl:
        dept = next(e[2] for e in EMPLOYEES if e[0]==u["employee_id"])
        if dept in acl["allowed_departments"]: return True
    return False

def allowed_rows(db_path, uid, table, extra_where="1=1"):
    u = user(uid); con = sqlite3.connect(db_path); con.row_factory = sqlite3.Row
    rows = con.execute(f"SELECT * FROM {table} WHERE ({DB_RULES[table][u['role']]}) AND ({extra_where})", {"emp":u["employee_id"]}).fetchall()
    out = []
    for r in rows:
        d = dict(r)
        for col, roles in COLUMN_RULES.get(table,{}).items():
            if u["role"] not in roles and d.get("employee_id")!=u["employee_id"]: d.pop(col)
        out.append(d)
    con.close(); return out

def export(out_dir):
    json.dump({"roles":ROLES,"users":[dict(user_id=u,employee_id=e,role=r) for u,e,r in USERS]},
              open(os.path.join(out_dir,"users_roles.json"),"w"),indent=2)
    json.dump({"documents":DOC_ACL,"db_row_rules":DB_RULES,"db_column_rules":COLUMN_RULES,
               "notes":"Image ACLs: allowed_employees = the person who owns/appears in the item."},
              open(os.path.join(out_dir,"acl_policy.json"),"w"),indent=2)
