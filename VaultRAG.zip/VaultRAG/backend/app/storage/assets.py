"""
AssetStore: Secure static/image file serving for VaultRAG.
Guards against path traversal by enforcing strict resolution within whitelisted root directories.
"""

from pathlib import Path
from typing import Sequence
import mimetypes

from app.config import settings


class AssetStore:
    """Whitelisted filesystem asset resolver with traversal protection."""

    def __init__(self, allowed_roots: Sequence[Path] | None = None):
        if allowed_roots is not None:
            self.roots = [Path(r).resolve() for r in allowed_roots]
        else:
            ds_path = settings.dataset_path()
            # Support both layout variants
            roots = [
                (ds_path / "dataset" / "corpus" / "images").resolve(),
                (ds_path / "corpus" / "images").resolve(),
                (ds_path / "dataset" / "corpus" / "pdfs").resolve(),
                (ds_path / "corpus" / "pdfs").resolve(),
                (ds_path / "dataset" / "corpus" / "poisoned").resolve(),
                (ds_path / "corpus" / "poisoned").resolve(),
                (Path(__file__).resolve().parent.parent.parent / "data" / "uploads").resolve(),
            ]
            self.roots = [r for r in roots if r.exists() or "uploads" in r.name]

    def resolve_asset_path(self, file_ref: str) -> Path:
        """
        Safely resolve a relative file_ref to a filesystem Path within whitelisted roots.
        Raises ValueError on path traversal attempts or invalid references.
        Raises FileNotFoundError if the file does not exist in any whitelisted root.
        """
        if not file_ref or not isinstance(file_ref, str):
            raise ValueError("file_ref must be a non-empty string")

        clean_ref = file_ref.replace("\\", "/").strip()

        # Reject path traversal patterns
        if ".." in clean_ref.split("/"):
            raise ValueError("Path traversal forbidden: '..' detected")
        if clean_ref.startswith("/") or ":" in clean_ref:
            raise ValueError("Absolute paths forbidden in file_ref")

        # Strip optional leading folder prefix (e.g., 'images/foo.png' -> 'foo.png')
        filename = clean_ref.split("/")[-1]

        for root in self.roots:
            candidate = (root / clean_ref).resolve()
            try:
                candidate.relative_to(root)
            except ValueError:
                continue

            if candidate.is_file():
                return candidate

            # Also try matching direct basename in the root
            candidate_base = (root / filename).resolve()
            try:
                candidate_base.relative_to(root)
            except ValueError:
                continue

            if candidate_base.is_file():
                return candidate_base

        raise FileNotFoundError(f"Asset not found for ref: {file_ref}")

    def get_asset(self, file_ref: str) -> tuple[bytes, str]:
        """
        Read asset bytes and return (content, mime_type).
        """
        path = self.resolve_asset_path(file_ref)
        content = path.read_bytes()

        mime, _ = mimetypes.guess_type(str(path))
        if not mime:
            if path.suffix.lower() == ".png":
                mime = "image/png"
            elif path.suffix.lower() in (".jpg", ".jpeg"):
                mime = "image/jpeg"
            else:
                mime = "application/octet-stream"

        return content, mime


# Singleton instance
asset_store = AssetStore()
