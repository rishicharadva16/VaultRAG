"""
Page Renderer & PDF Highlight Rect Computation for VaultRAG.
Renders PDF pages to PNG at ~150 DPI with disk caching keyed by (file_hash, page, dpi).
Computes normalized bounding boxes for highlighted chunk text aligned against PyMuPDF page words.
Sensitive text is never logged.
"""

from __future__ import annotations

import hashlib
import logging
from pathlib import Path
import re
from typing import Any
import pymupdf

logger = logging.getLogger(__name__)

# Base cache directory inside backend/data/cache/page_renders
_DEFAULT_CACHE_DIR = (Path(__file__).resolve().parent.parent.parent / "data" / "cache" / "page_renders")


def _get_file_hash(path: Path) -> str:
    """Compute sha256 hash of a file for cache keying."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()[:24]


def render_pdf_page(
    pdf_path: Path,
    page_num: int,
    dpi: int = 150,
    cache_dir: Path | None = None,
) -> bytes:
    """
    Render a single page (1-indexed) of a PDF to PNG at specified DPI.
    Caches rendered PNG on disk keyed by (file_hash, page_num, dpi).
    """
    if not pdf_path.is_file():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    target_cache_dir = cache_dir or _DEFAULT_CACHE_DIR
    target_cache_dir.mkdir(parents=True, exist_ok=True)

    file_hash = _get_file_hash(pdf_path)
    cache_file = target_cache_dir / f"{file_hash}_p{page_num}_{dpi}dpi.png"

    if cache_file.is_file():
        return cache_file.read_bytes()

    doc = pymupdf.open(str(pdf_path))
    try:
        if page_num < 1 or page_num > len(doc):
            raise IndexError(f"Page {page_num} out of bounds (1..{len(doc)})")
        fitz_page = doc[page_num - 1]
        scale = float(dpi) / 72.0
        mat = pymupdf.Matrix(scale, scale)
        pix = fitz_page.get_pixmap(matrix=mat, alpha=False)
        png_bytes = pix.tobytes("png")
        cache_file.write_bytes(png_bytes)
        return png_bytes
    finally:
        doc.close()


def get_pdf_page_count(pdf_path: Path) -> int:
    """Return total page count for a PDF file."""
    if not pdf_path.is_file():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")
    doc = pymupdf.open(str(pdf_path))
    try:
        return len(doc)
    finally:
        doc.close()


def normalize_token(w: str) -> str:
    """Normalize a word token for fuzzy matching."""
    return re.sub(r"[^\w]", "", w.lower())


def compute_pdf_highlight_rects(
    pdf_path: Path,
    page_num: int,
    chunk_text: str,
    highlight_spans: list[tuple[int, int]],
) -> tuple[list[dict[str, float]], str, float, float]:
    """
    Compute normalized bounding boxes {x, y, w, h} (0..1) for highlighted text on a PDF page.
    
    Returns:
      (rects, match_status, page_width, page_height)
      where match_status is 'exact', 'partial', or 'none'.
    """
    if not pdf_path.is_file():
        raise FileNotFoundError(f"PDF not found: {pdf_path}")

    doc = pymupdf.open(str(pdf_path))
    try:
        if page_num < 1 or page_num > len(doc):
            return [], "none", 0.0, 0.0

        fitz_page = doc[page_num - 1]
        page_w = float(fitz_page.rect.width)
        page_h = float(fitz_page.rect.height)
        if page_w <= 0 or page_h <= 0:
            return [], "none", 0.0, 0.0

        # Each word is (x0, y0, x1, y1, word_str, block_no, line_no, word_no)
        page_words = fitz_page.get_text("words")
        if not page_words:
            return [], "none", page_w, page_h

        if not highlight_spans:
            return [], "none", page_w, page_h

        page_tokens = [normalize_token(w[4]) for w in page_words]

        all_matched_words: list[Any] = []
        total_hl_tokens = 0
        matched_hl_tokens = 0

        for s, e in highlight_spans:
            s = max(0, min(len(chunk_text), s))
            e = max(0, min(len(chunk_text), e))
            if s >= e:
                continue

            hl_sub = chunk_text[s:e]
            hl_raw_tokens = hl_sub.split()
            hl_tokens = [normalize_token(w) for w in hl_raw_tokens if normalize_token(w)]
            if not hl_tokens:
                continue

            total_hl_tokens += len(hl_tokens)

            # 1. Exact sequence search
            found_slice = None
            k = len(hl_tokens)
            for i in range(len(page_tokens) - k + 1):
                if page_tokens[i : i + k] == hl_tokens:
                    found_slice = page_words[i : i + k]
                    matched_hl_tokens += k
                    break

            # 2. Sliding window search if exact sequence not found (tolerance for layout differences)
            if found_slice is None:
                best_overlap = 0
                best_subwords: list[Any] = []
                # Search window lengths near k
                min_win = max(1, k - 3)
                max_win = min(len(page_tokens), k + 4)
                for win_len in range(min_win, max_win + 1):
                    for i in range(len(page_tokens) - win_len + 1):
                        sub_tokens = page_tokens[i : i + win_len]
                        # Count matches preserving rough order
                        matches = sum(1 for tok in hl_tokens if tok in sub_tokens)
                        if matches > best_overlap:
                            best_overlap = matches
                            best_subwords = [w for w in page_words[i : i + win_len] if normalize_token(w[4]) in hl_tokens]

                if best_overlap > 0:
                    matched_hl_tokens += best_overlap
                    found_slice = best_subwords

            if found_slice:
                all_matched_words.extend(found_slice)

        if not all_matched_words:
            return [], "none", page_w, page_h

        # Group matched words by (block_no, line_no) into one rect per line
        lines: dict[tuple[int, int], list[Any]] = {}
        for w in all_matched_words:
            key = (w[5], w[6])
            lines.setdefault(key, []).append(w)

        rects: list[dict[str, float]] = []
        for (b_no, l_no), l_words in lines.items():
            min_x0 = min(w[0] for w in l_words)
            min_y0 = min(w[1] for w in l_words)
            max_x1 = max(w[2] for w in l_words)
            max_y1 = max(w[3] for w in l_words)

            norm_x = round(max(0.0, min(1.0, min_x0 / page_w)), 4)
            norm_y = round(max(0.0, min(1.0, min_y0 / page_h)), 4)
            norm_w = round(max(0.0, min(1.0 - norm_x, (max_x1 - min_x0) / page_w)), 4)
            norm_h = round(max(0.0, min(1.0 - norm_y, (max_y1 - min_y0) / page_h)), 4)

            rects.append({
                "x": norm_x,
                "y": norm_y,
                "w": norm_w,
                "h": norm_h,
            })

        # Match status classification
        ratio = (matched_hl_tokens / total_hl_tokens) if total_hl_tokens > 0 else 0.0
        if ratio >= 0.95:
            match_status = "exact"
        elif ratio >= 0.01:
            match_status = "partial"
        else:
            match_status = "none"
            rects = []

        return rects, match_status, round(page_w, 2), round(page_h, 2)
    finally:
        doc.close()
